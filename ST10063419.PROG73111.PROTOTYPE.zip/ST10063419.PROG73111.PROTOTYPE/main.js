function toggleScreen(screenId) {
    // Hide all screens
    document.querySelectorAll('.app-screen').forEach(screen => {
        screen.classList.add('hidden');
    });
    // Show selected screen
    document.getElementById(screenId).classList.remove('hidden');
}

function triggerFeedback() {
    var x = document.getElementById("snackbar");
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}

// Update Energy Label on slider move
const slider = document.getElementById('energySlider');
if(slider) {
    slider.oninput = function() {
        const val = document.getElementById('energyVal');
        if(this.value < 33) val.innerHTML = "Low Energy";
        else if(this.value < 66) val.innerHTML = "Moderate Energy";
        else val.innerHTML = "High Energy";
    }
}